from django.shortcuts import render
# Create your views here.
def home(request):
    return render(request,'index.html')

def ind(request):
    return render(request,'india_second.html')

def gn(request):
    return render(request,'gandhinagar.html')

def mumbai(request):
    return render(request,'mumbai.html')

def australia(request):
    return render(request,'melbourne.html')