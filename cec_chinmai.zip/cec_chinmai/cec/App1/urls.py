from django.contrib import admin
from django.urls import path
from App1 import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home),
    path('india_second',views.ind),
    path('Gandhinagar',views.gn),
    path('Mumbai',views.mumbai),
    path('australia_inside',views.australia),


]